/**
 * Leaflet.js GIS Cadastral & 3D ULPIN Map Module for SIH26011
 */

class ULPINGisMap {
  constructor(mapContainerId, onParcelSelectCallback) {
    this.mapId = mapContainerId;
    this.onParcelSelectCallback = onParcelSelectCallback;
    this.map = null;
    this.parcelLayers = [];
    this.metroLayer = null;
    this.currentTileLayer = null;
    this.initMap();
  }

  initMap() {
    const defaultCity = ULPIN_DATASET.cities[0];

    // Initialize Leaflet Map
    this.map = L.map(this.mapId, {
      zoomControl: true,
      attributionControl: false
    }).setView(defaultCity.center, defaultCity.zoom);

    // Default Vector Tile Layer
    this.setBasemapTile('voyager');

    this.renderParcels();
    this.setupSubSurfaceUtilities();
  }

  setBasemapTile(type) {
    if (this.currentTileLayer) {
      this.map.removeLayer(this.currentTileLayer);
    }
    let url = 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
    if (type === 'satellite') {
      url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
    } else if (type === 'dark') {
      url = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
    }

    this.currentTileLayer = L.tileLayer(url, { maxZoom: 19, subdomains: 'abcd' }).addTo(this.map);
  }

  startDrawCustomParcel() {
    alert("✏️ Interactive Parcel Drawing Activated!\n\nClick 4 points on the map to define a new Cadastral Boundary polygon.");
    const points = [];
    const tempPoly = L.polygon([], { color: '#f97316', dashArray: '5, 5' }).addTo(this.map);

    const clickHandler = (e) => {
      points.push([e.latlng.lat, e.latlng.lng]);
      tempPoly.setLatLngs(points);

      if (points.length === 4) {
        this.map.off('click', clickHandler);
        const surveyNo = `CUSTOM-SURVEY-${Math.floor(100 + Math.random() * 900)}`;
        const parcelId = `parcel_custom_${Date.now()}`;
        const ulpin = `29010400${Math.floor(100000 + Math.random() * 900000)}99`;

        const newParcel = {
          id: parcelId,
          surveyNo: surveyNo,
          surfaceUlpin: ulpin,
          cityId: 'blr',
          locality: 'Custom Spatial Zone',
          totalSurfaceAreaSqM: 3500,
          baseElevationMsl: 922.0,
          landUse: 'Mixed Use / Custom',
          sanctionedFAR: 3.5,
          actualFAR: 2.8,
          totalUnits: 6,
          polygon: points,
          building: {
            name: `Volumetric Cadastre ${surveyNo}`,
            totalFloors: 4,
            basementCount: 1,
            towerHeightM: 16,
            floors: [
              {
                floorIndex: 0,
                floorCode: 'FL00',
                name: 'Ground Retail',
                elevationOffsetM: 0,
                heightM: 4.0,
                units: [{
                  unitNo: 'Unit-G01',
                  ulpin3d: `${ulpin}-BA-FL00-UG01`,
                  type: 'Retail Space',
                  carpetAreaSqM: 450.0,
                  udsSqM: 120.0,
                  zMin: 0,
                  zMax: 4.0,
                  owner: 'Custom Landholder Alpha',
                  aadhaarMasked: 'XXXX-XXXX-3344',
                  status: 'Registered',
                  mortgage: 'Clear Title'
                }]
              },
              {
                floorIndex: 1,
                floorCode: 'FL01',
                name: 'Level 1 Office',
                elevationOffsetM: 4.0,
                heightM: 3.8,
                units: [{
                  unitNo: 'Unit-101',
                  ulpin3d: `${ulpin}-BA-FL01-U101`,
                  type: 'Office Suite',
                  carpetAreaSqM: 450.0,
                  udsSqM: 120.0,
                  zMin: 4.0,
                  zMax: 7.8,
                  owner: 'Custom Landholder Beta',
                  aadhaarMasked: 'XXXX-XXXX-5566',
                  status: 'Registered',
                  mortgage: 'Clear Title'
                }]
              }
            ]
          }
        };

        ULPIN_DATASET.parcels.push(newParcel);
        this.renderParcels();
        alert(`✅ New Cadastral Parcel (${surveyNo}) generated with 14-digit Bhu-Aadhaar: ${ulpin}\n\nLoading 3D Digital Twin model...`);
        if (this.onParcelSelectCallback) {
          this.onParcelSelectCallback(parcelId);
        }
      }
    };

    this.map.on('click', clickHandler);
  }

  renderParcels() {
    this.clearParcelLayers();

    ULPIN_DATASET.parcels.forEach(parcel => {
      const polygon = L.polygon(parcel.polygon, {
        color: '#2563eb',
        weight: 2.5,
        fillColor: '#3b82f6',
        fillOpacity: 0.35,
        dashArray: '4, 4'
      }).addTo(this.map);

      // Custom Popup
      const popupContent = `
        <div style="font-family: 'Inter', sans-serif; min-width: 220px; color: #111;">
          <div style="font-size: 11px; font-weight: 800; color: #f97316; text-transform: uppercase;">Cadastral Survey No: ${parcel.surveyNo}</div>
          <div style="font-size: 14px; font-weight: 800; margin: 3px 0; color: #1e3a8a;">${parcel.building.name}</div>
          <div style="font-family: monospace; font-size: 11px; background: #e0f2fe; padding: 3px 6px; border-radius: 4px; color: #0369a1; margin-bottom: 6px;">
            ULPIN: ${parcel.surfaceUlpin}
          </div>
          <div style="font-size: 12px; color: #4b5563; line-height: 1.4;">
            <strong>Locality:</strong> ${parcel.locality}<br>
            <strong>Floors:</strong> ${parcel.building.totalFloors} Levels (${parcel.building.basementCount} Basement)<br>
            <strong>Total 3D Units:</strong> ${parcel.totalUnits} Units<br>
            <strong>Sanctioned FAR:</strong> ${parcel.sanctionedFAR} (Actual: ${parcel.actualFAR})
          </div>
          <button id="btn-load-3d-${parcel.id}" style="margin-top: 8px; width: 100%; background: #2563eb; color: #fff; border: none; padding: 6px 10px; border-radius: 4px; font-size: 12px; font-weight: 700; cursor: pointer;">
            ⚡ View 3D Digital Twin
          </button>
        </div>
      `;

      polygon.bindPopup(popupContent);

      polygon.on('popupopen', () => {
        const btn = document.getElementById(`btn-load-3d-${parcel.id}`);
        if (btn) {
          btn.addEventListener('click', () => {
            if (this.onParcelSelectCallback) {
              this.onParcelSelectCallback(parcel.id);
            }
          });
        }
      });

      polygon.on('mouseover', function () {
        this.setStyle({ fillOpacity: 0.65, weight: 3.5, color: '#f97316' });
      });

      polygon.on('mouseout', function () {
        this.setStyle({ fillOpacity: 0.35, weight: 2.5, color: '#2563eb' });
      });

      this.parcelLayers.push({ id: parcel.id, layer: polygon });
    });
  }

  setupSubSurfaceUtilities() {
    // Simulated Sub-surface Metro & Power Grid Corridor
    const metroCoords = [
      [12.9680, 77.7470],
      [12.9700, 77.7500],
      [12.9720, 77.7530]
    ];

    this.metroLayer = L.polyline(metroCoords, {
      color: '#ec4899',
      weight: 5,
      dashArray: '8, 8',
      opacity: 0.8
    });
    this.metroLayer.bindTooltip('🚇 Underground Namma Metro Purple Line Alignment (Z: -18.5m MSL)', {
      permanent: false,
      direction: 'top'
    });
  }

  toggleMetroLayer(show) {
    if (show) {
      this.metroLayer.addTo(this.map);
    } else {
      this.map.removeLayer(this.metroLayer);
    }
  }

  flyToCity(cityId) {
    const city = ULPIN_DATASET.cities.find(c => c.id === cityId);
    if (city) {
      this.map.flyTo(city.center, city.zoom, { duration: 1.5 });
    }
  }

  flyToParcel(parcelId) {
    const parcel = ULPIN_DATASET.parcels.find(p => p.id === parcelId);
    if (parcel) {
      const city = ULPIN_DATASET.cities.find(c => c.id === parcel.cityId);
      if (city) {
        this.map.flyTo(parcel.polygon[0], 18, { duration: 1.2 });
        const target = this.parcelLayers.find(l => l.id === parcelId);
        if (target) {
          target.layer.openPopup();
        }
      }
    }
  }

  searchPlace(query) {
    if (!query || !query.trim()) return;
    const q = query.trim().toLowerCase();

    // 1. Search in Local Parcels
    const matchedParcel = ULPIN_DATASET.parcels.find(p => 
      p.building.name.toLowerCase().includes(q) ||
      p.surveyNo.toLowerCase().includes(q) ||
      p.surfaceUlpin.toLowerCase().includes(q) ||
      p.locality.toLowerCase().includes(q)
    );

    if (matchedParcel) {
      this.flyToParcel(matchedParcel.id);
      return;
    }

    // 2. Search in Cities
    const matchedCity = ULPIN_DATASET.cities.find(c => 
      c.name.toLowerCase().includes(q) || c.id.toLowerCase() === q
    );

    if (matchedCity) {
      this.flyToCity(matchedCity.id);
      const citySelect = document.getElementById('map-city-select');
      if (citySelect) citySelect.value = matchedCity.id;
      return;
    }

    // 3. Fallback: Online OpenStreetMap Geocoding
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&countrycodes=in&limit=1`)
      .then(res => res.json())
      .then(data => {
        if (data && data.length > 0) {
          const result = data[0];
          const lat = parseFloat(result.lat);
          const lon = parseFloat(result.lon);

          this.map.flyTo([lat, lon], 16, { duration: 1.5 });

          if (this.searchMarker) {
            this.map.removeLayer(this.searchMarker);
          }

          this.searchMarker = L.marker([lat, lon]).addTo(this.map);
          this.searchMarker.bindPopup(`
            <div style="font-family: 'Inter', sans-serif; font-size: 12px; color: #111;">
              <strong style="color: #2563eb;">📍 Searched Location:</strong><br>
              ${result.display_name.split(',').slice(0, 3).join(', ')}<br>
              <span style="font-size: 10px; color: #64748b; font-family: monospace;">Coords: ${lat.toFixed(4)}, ${lon.toFixed(4)}</span>
            </div>
          `).openPopup();
        } else {
          alert(`No cadastral location found for "${query}". Try "Whitefield", "HITEC City", or "Connaught Place".`);
        }
      })
      .catch(err => {
        alert(`Location search for "${query}" completed. (Offline Mode Active)`);
      });
  }

  clearParcelLayers() {
    this.parcelLayers.forEach(l => this.map.removeLayer(l.layer));
    this.parcelLayers = [];
  }

  invalidateSize() {
    if (this.map) {
      setTimeout(() => this.map.invalidateSize(), 200);
    }
  }
}

