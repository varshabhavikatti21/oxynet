# Bhu-Aadhaar 3D: Vertical Property Mapping & 3D ULPIN Generation System
### Problem Statement: SIH26011 (Smart India Hackathon)
**Department / Ministry:** Department of Land Resources (DoLR), Ministry of Rural Development, Govt. of India.

---

## 🌟 Executive Summary
In modern urban India, multiple property owners (apartments, commercial suites, sub-surface parking, air rights) occupy the exact same 2D geographic footprint. Traditional 2D ULPIN (14-digit Bhu-Aadhaar) represents only surface land parcels (X, Y coordinates), creating severe ambiguity, overlapping claims, and lack of vertical legal clarity.

**Bhu-Aadhaar 3D** solves this by extending India's 14-digit ULPIN standard into a **4D/LoD3 Volumetric Spatial Cadastre Engine** incorporating the Z-axis (height above ground level and MSL elevation), Undivided Share of Land (UDS) validation, and sub-surface utility layers.

---

## 📐 Standardized 3D ULPIN Syntax (Govt-Compliant)

```
[ STATE(2) + DIST(2) + TEHSIL(2) + VILLAGE(6) + PARCEL(2) ] - [ BLK(2) ] - [ FLR(3) ] - [ UNIT(4) ]
```

### Example:
`29010400281901-BA-FL01-U101`
- **29**: Karnataka (State Code)
- **01**: Bengaluru Urban (District)
- **04**: KR Puram / Mahadevapura (Taluk/Tehsil)
- **002819**: Whitefield (LGD Census Village/Ward Code)
- **01**: Cadastral Surface Parcel 142/2A
- **BA**: Block Alpha
- **FL01**: Level 1 (+4.5m to +8.3m AGL)
- **U101**: Unit 101 (1,200 sq.m Office Suite, UDS: 410 sq.m)

---

## 🚀 Key Innovation Highlights for Hackathon Presentation

1. **Interactive 3D Digital Twin (Three.js)**:
   - **Exploded View Slider**: Dynamically separates floors along the Z-axis to inspect vertical stratification.
   - **X-Ray / Transparency Mode**: Reveals internal core shafts, elevator cores, and unit divisions.
   - **Unit-Level Raycasting Selection**: Click on any flat, office suite, or basement parking bay to inspect live legal ownership, Aadhaar hash, carpet area, and UDS %.
   - **Dynamic Styling Modes**: View by Registration Status (Green/Amber/Red/Blue), Land Use category, or Floor spectrum.

2. **2D-3D Interlinked GIS Cadastre (Leaflet.js)**:
   - Real urban high-density corridors: Bengaluru (Whitefield IT Hub), Hyderabad (HITEC City), New Delhi (Connaught Place).
   - Cadastral parcel polygons linked directly to the 3D visualizer.
   - Sub-surface Z-corridor layer (Namma Metro Purple Line alignment at Z: -18.5m MSL).

3. **Automated 3D ULPIN Coding Engine**:
   - Interactive generator computing 14-digit surface + 3D vertical extension + volumetric bounding envelope in $m^3$.

4. **Official 3D Bhu-Aadhaar Deed Certificate**:
   - High-fidelity Govt of India certificate preview with real-time QR Code generation and instant print/PDF export.

5. **Smart Mutation Ledger**:
   - End-to-end simulated mutation workflow with digital Sub-Registrar sign-off, e-Stamp duty verification, and audit logs.

6. **DigiLocker Integration Gateway**:
   - Instant retrieval of Kaveri 2.0 / IGRS registered title deeds, e-Khata, and Encumbrance Certificates (EC).

---

## 💻 How to Run Locally

You can run this application by opening `index.html` in any modern web browser or using a simple local server:

```bash
cd "c:\Users\HP\Desktop\SHI hackothon\ulpin-3d-system"
python -m http.server 8080
```
Then visit: **`http://localhost:8080/`**
