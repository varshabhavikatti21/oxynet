/**
 * Three.js 3D Vertical Property Visualizer for SIH26011
 * Handles realistic high-rise rendering, volumetric unit partitioning,
 * layer explosion, X-ray transparency, raycasting selection, and status styling.
 */

class ULPIN3DViewer {
  constructor(canvasContainerId, onSelectCallback) {
    this.container = document.getElementById(canvasContainerId);
    this.onSelectCallback = onSelectCallback;
    
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.controls = null;
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();
    
    this.currentParcel = null;
    this.floorMeshes = [];
    this.unitMeshes = [];
    this.groundMesh = null;
    this.shaftMesh = null;
    
    this.explodeFactor = 0; // 0 (compact) to 1 (max exploded)
    this.isXRayMode = false;
    this.isSubsurfaceVisible = false;
    this.isARMode = false;
    this.colorMode = 'status'; // 'status', 'use', 'floor'
    this.selectedMesh = null;
    this.hoveredMesh = null;
    this.subsurfaceGroup = null;
    this.lidarPointCloud = null;
    this.timeOfDay = 'day'; // 'day', 'sunset', 'night'
    this.farViolationMesh = null;
    this.facadeTexture = this.generateFacadeTexture();
    this.solarTexture = this.generateSolarTexture();
    this.helipadTexture = this.generateHelipadTexture();

    this.ambientLight = null;
    this.dirLight1 = null;
    this.dirLight2 = null;
    this.subSurfaceLight = null;

    this.initScene();
    this.setupEvents();
    this.animate();
  }

  generateFacadeTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');

    // Base glass tint
    ctx.fillStyle = '#0f2b48';
    ctx.fillRect(0, 0, 256, 256);

    // Window grid
    const cols = 4;
    const rows = 3;
    const pad = 8;
    const w = (256 - (cols + 1) * pad) / cols;
    const h = (256 - (rows + 1) * pad) / rows;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const x = pad + c * (w + pad);
        const y = pad + r * (h + pad);
        
        // Window glass gradient
        const grad = ctx.createLinearGradient(x, y, x + w, y + h);
        grad.addColorStop(0, 'rgba(147, 197, 253, 0.45)');
        grad.addColorStop(0.5, 'rgba(59, 130, 246, 0.25)');
        grad.addColorStop(1, 'rgba(30, 58, 138, 0.55)');

        ctx.fillStyle = grad;
        ctx.fillRect(x, y, w, h);

        // Window frame
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(x, y, w, h);
      }
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(2, 1);
    return tex;
  }

  generateSolarTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#1e3a8a';
    ctx.fillRect(0, 0, 128, 128);
    ctx.strokeStyle = '#60a5fa';
    ctx.lineWidth = 2;
    for (let i = 0; i <= 128; i += 16) {
      ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 128); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(128, i); ctx.stroke();
    }
    return new THREE.CanvasTexture(canvas);
  }

  generateHelipadTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, 256, 256);
    // Outer yellow circle
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.arc(128, 128, 90, 0, Math.PI * 2);
    ctx.stroke();
    // 'H'
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 96px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('H', 128, 128);
    return new THREE.CanvasTexture(canvas);
  }

  initScene() {
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0f1d);
    this.scene.fog = new THREE.FogExp2(0x0a0f1d, 0.015);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 1000);
    this.camera.position.set(38, 28, 48);

    // 3. Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.container.appendChild(this.renderer.domElement);

    // 4. OrbitControls
    this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.05;
    this.controls.maxPolarAngle = Math.PI / 2 + 0.25; // allow looking underground
    this.controls.minDistance = 10;
    this.controls.maxDistance = 150;
    this.controls.target.set(0, 8, 0);

    // 5. Lighting
    this.setupLights();

    // 6. Cadastral Base Grid & Sub-Surface Utilities
    this.setupGround();
    this.setupSubsurfaceUtilities();
    this.setupLidarPointCloud();
  }

  setupLights() {
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
    this.scene.add(this.ambientLight);

    this.dirLight1 = new THREE.DirectionalLight(0xffffff, 0.95);
    this.dirLight1.position.set(40, 60, 30);
    this.dirLight1.castShadow = true;
    this.dirLight1.shadow.mapSize.width = 2048;
    this.dirLight1.shadow.mapSize.height = 2048;
    this.scene.add(this.dirLight1);

    this.dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.45);
    this.dirLight2.position.set(-30, 20, -30);
    this.scene.add(this.dirLight2);

    this.subSurfaceLight = new THREE.DirectionalLight(0xf97316, 0.4);
    this.subSurfaceLight.position.set(0, -30, 0);
    this.scene.add(this.subSurfaceLight);
  }

  setupGround() {
    // 2D Cadastral Base Plane
    const groundGeo = new THREE.PlaneGeometry(100, 100);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.9,
      metalness: 0.1
    });
    this.groundMesh = new THREE.Mesh(groundGeo, groundMat);
    this.groundMesh.rotation.x = -Math.PI / 2;
    this.groundMesh.position.y = 0;
    this.groundMesh.receiveShadow = true;
    this.scene.add(this.groundMesh);

    // Grid Overlay
    const gridHelper = new THREE.GridHelper(80, 40, 0x2563eb, 0x1e293b);
    gridHelper.position.y = 0.02;
    this.scene.add(gridHelper);

    // Sub-surface Z-depth Grid (Negative altitude)
    const subGridHelper = new THREE.GridHelper(80, 40, 0xf97316, 0x332211);
    subGridHelper.position.y = -8.0;
    this.scene.add(subGridHelper);
  }

  setupSubsurfaceUtilities() {
    this.subsurfaceGroup = new THREE.Group();
    this.subsurfaceGroup.visible = false;

    // 1. Metro Tunnel (Z: -18.5m MSL)
    const tunnelGeo = new THREE.CylinderGeometry(3.5, 3.5, 90, 32);
    const tunnelMat = new THREE.MeshStandardMaterial({
      color: 0xec4899,
      wireframe: false,
      transparent: true,
      opacity: 0.65,
      roughness: 0.3
    });
    const metroTunnel = new THREE.Mesh(tunnelGeo, tunnelMat);
    metroTunnel.rotation.z = Math.PI / 2;
    metroTunnel.position.set(0, -14, 15);
    this.subsurfaceGroup.add(metroTunnel);

    // Metro wireframe ring accents
    const tunnelEdges = new THREE.EdgesGeometry(tunnelGeo);
    const tunnelLineMat = new THREE.LineBasicMaterial({ color: 0xf472b6 });
    const tunnelLines = new THREE.LineSegments(tunnelEdges, tunnelLineMat);
    metroTunnel.add(tunnelLines);

    // 2. Main Water Pipeline (Z: -4m)
    const pipeGeo = new THREE.CylinderGeometry(1.2, 1.2, 80, 16);
    const pipeMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.8 });
    const waterPipe = new THREE.Mesh(pipeGeo, pipeMat);
    waterPipe.rotation.x = Math.PI / 2;
    waterPipe.position.set(12, -4, 0);
    this.subsurfaceGroup.add(waterPipe);

    // 3. High Voltage Power Corridor (Z: -6m)
    const cableGeo = new THREE.CylinderGeometry(0.8, 0.8, 80, 16);
    const cableMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.85 });
    const powerCable = new THREE.Mesh(cableGeo, cableMat);
    powerCable.rotation.x = Math.PI / 2;
    powerCable.position.set(-12, -6, 0);
    this.subsurfaceGroup.add(powerCable);

    // 4. Structural Concrete Piles
    const pilePositions = [
      [-8, -8], [8, -8], [-8, 8], [8, 8]
    ];
    pilePositions.forEach(([x, z]) => {
      const pileGeo = new THREE.CylinderGeometry(1.0, 1.0, 16, 16);
      const pileMat = new THREE.MeshStandardMaterial({ color: 0x64748b });
      const pile = new THREE.Mesh(pileGeo, pileMat);
      pile.position.set(x, -8, z);
      this.subsurfaceGroup.add(pile);
    });

    this.scene.add(this.subsurfaceGroup);
  }

  setupLidarPointCloud() {
    const pointCount = 1500;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(pointCount * 3);
    const colors = new Float32Array(pointCount * 3);

    for (let i = 0; i < pointCount; i++) {
      const x = (Math.random() - 0.5) * 30;
      const y = Math.random() * 35;
      const z = (Math.random() - 0.5) * 26;

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      colors[i * 3] = 0.2;     // R
      colors[i * 3 + 1] = 0.8; // G
      colors[i * 3 + 2] = 1.0; // B
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 0.35,
      vertexColors: true,
      transparent: true,
      opacity: 0.75
    });

    this.lidarPointCloud = new THREE.Points(geometry, material);
    this.lidarPointCloud.visible = false;
    this.scene.add(this.lidarPointCloud);
  }

  loadBuilding(parcelData) {
    this.currentParcel = parcelData;
    this.clearBuilding();

    const building = parcelData.building;
    const floors = building.floors;
    const blockWidth = 18;
    const blockDepth = 14;

    // Elevator / Core Shaft in center
    const shaftHeight = building.towerHeightM * 0.7;
    const shaftGeo = new THREE.BoxGeometry(4, shaftHeight, 4);
    const shaftMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.7,
      transparent: true,
      opacity: 0.8
    });
    this.shaftMesh = new THREE.Mesh(shaftGeo, shaftMat);
    this.shaftMesh.position.set(0, shaftHeight / 2 - 4, 0);
    this.scene.add(this.shaftMesh);

    // Build Each Floor and Units
    floors.forEach((floor, fIdx) => {
      const floorHeight = floor.heightM || 3.5;
      const baseOffsetY = floor.elevationOffsetM || (fIdx * 4);

      // Floor group allows exploding vertical offset
      const floorGroup = new THREE.Group();
      floorGroup.userData = {
        floorData: floor,
        baseY: baseOffsetY + floorHeight / 2,
        floorHeight: floorHeight,
        floorIndex: floor.floorIndex
      };

      // Create units for this floor
      const unitCount = floor.units.length;
      floor.units.forEach((unit, uIdx) => {
        let uWidth, uDepth, uPosX, uPosZ;

        if (unitCount === 1) {
          uWidth = blockWidth - 0.6;
          uDepth = blockDepth - 0.6;
          uPosX = 0;
          uPosZ = 0;
        } else if (unitCount === 2) {
          uWidth = (blockWidth / 2) - 0.8;
          uDepth = blockDepth - 0.8;
          uPosX = (uIdx === 0) ? -(blockWidth / 4) : (blockWidth / 4);
          uPosZ = 0;
        } else {
          uWidth = (blockWidth / 2) - 0.8;
          uDepth = (blockDepth / 2) - 0.8;
          uPosX = (uIdx % 2 === 0) ? -(blockWidth / 4) : (blockWidth / 4);
          uPosZ = (uIdx < 2) ? -(blockDepth / 4) : (blockDepth / 4);
        }

        const unitGeo = new THREE.BoxGeometry(uWidth, floorHeight - 0.3, uDepth);
        const unitColor = this.getUnitColor(unit, floor);
        const unitMat = new THREE.MeshStandardMaterial({
          color: unitColor,
          roughness: 0.2,
          metalness: 0.3,
          map: this.facadeTexture,
          transparent: true,
          opacity: this.isXRayMode ? 0.35 : 0.92,
          polygonOffset: true,
          polygonOffsetFactor: 1,
          polygonOffsetUnits: 1
        });

        const unitMesh = new THREE.Mesh(unitGeo, unitMat);
        unitMesh.position.set(uPosX, 0, uPosZ);
        unitMesh.castShadow = true;
        unitMesh.receiveShadow = true;

        unitMesh.userData = {
          type: 'unit',
          unitData: unit,
          floorData: floor,
          parcelData: parcelData,
          originalColor: unitColor
        };

        // Wireframe edges for high-tech architectural CAD look
        const edges = new THREE.EdgesGeometry(unitGeo);
        const lineMat = new THREE.LineBasicMaterial({
          color: 0x93c5fd,
          linewidth: 1.5,
          transparent: true,
          opacity: 0.65
        });
        const edgeLine = new THREE.LineSegments(edges, lineMat);
        unitMesh.add(edgeLine);

        floorGroup.add(unitMesh);
        this.unitMeshes.push(unitMesh);
      });

      // Floor slab base
      const slabGeo = new THREE.BoxGeometry(blockWidth + 0.4, 0.3, blockDepth + 0.4);
      const slabMat = new THREE.MeshStandardMaterial({
        color: floor.floorIndex < 0 ? 0x1e293b : 0x475569,
        roughness: 0.8
      });
      const slabMesh = new THREE.Mesh(slabGeo, slabMat);
      slabMesh.position.set(0, -floorHeight / 2 + 0.15, 0);
      floorGroup.add(slabMesh);

      floorGroup.position.y = floorGroup.userData.baseY;
      this.scene.add(floorGroup);
      this.floorMeshes.push(floorGroup);
    });

    // Rooftop Slab with Helipad or Solar Array
    const topFloor = floors[floors.length - 1];
    const topY = (topFloor.elevationOffsetM || ((floors.length - 1) * 4)) + (topFloor.heightM || 3.5);
    const roofGeo = new THREE.BoxGeometry(blockWidth, 0.4, blockDepth);
    const roofMat = new THREE.MeshStandardMaterial({
      map: (parcelData.landUse && parcelData.landUse.includes('Commercial')) ? this.helipadTexture : this.solarTexture,
      roughness: 0.5
    });
    const roofMesh = new THREE.Mesh(roofGeo, roofMat);
    roofMesh.position.set(0, topY + 0.2, 0);
    this.scene.add(roofMesh);
    this.floorMeshes.push(roofMesh);

    // Animate camera focus
    this.focusCamera();
  }

  getUnitColor(unit, floor) {
    if (this.colorMode === 'status') {
      switch (unit.status) {
        case 'Registered': return 0x10b981; // Green
        case 'Disputed': return 0xef4444;   // Red
        case 'Pending Mutation': return 0xf59e0b; // Amber
        case 'Government/Common': return 0x38bdf8; // Sky Blue
        default: return 0x8b5cf6;
      }
    } else if (this.colorMode === 'use') {
      if (unit.type.includes('Parking')) return 0x475569;
      if (unit.type.includes('Retail') || unit.type.includes('F&B')) return 0xec4899;
      if (unit.type.includes('Residential')) return 0x10b981;
      if (unit.type.includes('Common')) return 0x0ea5e9;
      return 0x3b82f6;
    } else if (this.colorMode === 'floor') {
      const hue = ((floor.floorIndex + 3) * 45) % 360;
      return new THREE.Color(`hsl(${hue}, 70%, 50%)`).getHex();
    }
    return 0x2563eb;
  }

  clearBuilding() {
    this.floorMeshes.forEach(fg => this.scene.remove(fg));
    this.floorMeshes = [];
    this.unitMeshes = [];
    if (this.shaftMesh) {
      this.scene.remove(this.shaftMesh);
      this.shaftMesh = null;
    }
    this.selectedMesh = null;
  }

  setExplode(val) {
    this.explodeFactor = parseFloat(val);
    this.floorMeshes.forEach((fg, idx) => {
      const baseY = fg.userData.baseY;
      const fIdx = fg.userData.floorIndex;
      // Spread outwards from ground floor (0)
      const explodeOffset = fIdx * this.explodeFactor * 8.0;
      fg.position.y = baseY + explodeOffset;
    });
  }

  setXRay(enabled) {
    this.isXRayMode = enabled;
    this.unitMeshes.forEach(mesh => {
      mesh.material.opacity = enabled ? 0.3 : 0.88;
      mesh.material.needsUpdate = true;
    });
  }

  setSubSurface(enabled) {
    this.isSubsurfaceVisible = enabled;
    if (this.subsurfaceGroup) {
      this.subsurfaceGroup.visible = enabled;
    }
    if (this.groundMesh) {
      this.groundMesh.material.opacity = enabled ? 0.4 : 1.0;
      this.groundMesh.material.transparent = enabled;
      this.groundMesh.material.needsUpdate = true;
    }
  }

  setARSpatial(enabled) {
    this.isARMode = enabled;
    if (this.lidarPointCloud) {
      this.lidarPointCloud.visible = enabled;
    }
    this.unitMeshes.forEach(mesh => {
      mesh.material.wireframe = enabled;
      mesh.material.needsUpdate = true;
    });
  }

  setAutoRotate(enabled) {
    if (this.controls) {
      this.controls.autoRotate = enabled;
      this.controls.autoRotateSpeed = 2.0;
    }
  }

  setTimeOfDay(timeMode) {
    this.timeOfDay = timeMode;
    if (timeMode === 'day') {
      this.scene.background = new THREE.Color(0x0a0f1d);
      this.scene.fog.color = new THREE.Color(0x0a0f1d);
      if (this.ambientLight) { this.ambientLight.color.setHex(0xffffff); this.ambientLight.intensity = 0.75; }
      if (this.dirLight1) { this.dirLight1.color.setHex(0xffffff); this.dirLight1.intensity = 0.95; this.dirLight1.position.set(40, 60, 30); }
      if (this.dirLight2) { this.dirLight2.color.setHex(0x38bdf8); this.dirLight2.intensity = 0.45; }
      this.unitMeshes.forEach(m => {
        if (m !== this.selectedMesh) m.material.emissive.setHex(0x000000);
      });
    } else if (timeMode === 'sunset') {
      this.scene.background = new THREE.Color(0x28122c);
      this.scene.fog.color = new THREE.Color(0x28122c);
      if (this.ambientLight) { this.ambientLight.color.setHex(0xfecdd3); this.ambientLight.intensity = 0.6; }
      if (this.dirLight1) { this.dirLight1.color.setHex(0xf97316); this.dirLight1.intensity = 1.2; this.dirLight1.position.set(50, 25, 40); }
      if (this.dirLight2) { this.dirLight2.color.setHex(0xa855f7); this.dirLight2.intensity = 0.5; }
      this.unitMeshes.forEach(m => {
        if (m !== this.selectedMesh) {
          m.material.emissive.setHex(0xf59e0b);
          m.material.emissiveIntensity = 0.15;
        }
      });
    } else if (timeMode === 'night') {
      this.scene.background = new THREE.Color(0x020617);
      this.scene.fog.color = new THREE.Color(0x020617);
      if (this.ambientLight) { this.ambientLight.color.setHex(0x1e293b); this.ambientLight.intensity = 0.35; }
      if (this.dirLight1) { this.dirLight1.color.setHex(0x38bdf8); this.dirLight1.intensity = 0.3; this.dirLight1.position.set(30, 40, 30); }
      if (this.dirLight2) { this.dirLight2.color.setHex(0x6366f1); this.dirLight2.intensity = 0.4; }
      this.unitMeshes.forEach(m => {
        if (m !== this.selectedMesh) {
          m.material.emissive.setHex(0x38bdf8);
          m.material.emissiveIntensity = 0.38;
        }
      });
    }
  }

  setFARViolation(enabled) {
    if (this.farViolationMesh) {
      this.scene.remove(this.farViolationMesh);
      this.farViolationMesh = null;
    }

    if (enabled && this.floorMeshes.length > 0) {
      // Highlight top floor with red holographic bounding box
      const topFloorMesh = this.floorMeshes[this.floorMeshes.length - 2] || this.floorMeshes[0];
      const boxGeo = new THREE.BoxGeometry(22, 6, 22);
      const boxMat = new THREE.MeshBasicMaterial({
        color: 0xef4444,
        wireframe: true,
        transparent: true,
        opacity: 0.8
      });
      this.farViolationMesh = new THREE.Mesh(boxGeo, boxMat);
      this.farViolationMesh.position.copy(topFloorMesh.position);
      this.farViolationMesh.position.y += 2;
      this.scene.add(this.farViolationMesh);
    }
  }

  addFloorLevel() {
    if (!this.currentParcel) return;
    const building = this.currentParcel.building;
    const lastFloor = building.floors[building.floors.length - 1];
    const newFloorIndex = lastFloor.floorIndex + 1;
    const newElevation = lastFloor.elevationOffsetM + lastFloor.heightM;
    const floorCode = `FL${newFloorIndex < 10 ? '0' + newFloorIndex : newFloorIndex}`;

    const newUnit = {
      unitNo: `Unit-${newFloorIndex}01`,
      ulpin3d: `${this.currentParcel.surfaceUlpin}-BA-${floorCode}-U${newFloorIndex}01`,
      type: "Residential Suite (Custom Build)",
      carpetAreaSqM: 115.0,
      udsSqM: 32.5,
      zMin: newElevation,
      zMax: newElevation + 3.8,
      owner: "New Allottee / Custom Floor",
      aadhaarMasked: "XXXX-XXXX-9900",
      status: "Pending Mutation",
      mortgage: "Clear Title"
    };

    const newFloor = {
      floorIndex: newFloorIndex,
      floorCode: floorCode,
      name: `Level ${newFloorIndex} (Custom Add)`,
      elevationOffsetM: newElevation,
      heightM: 3.8,
      units: [newUnit]
    };

    building.floors.push(newFloor);
    building.totalFloors += 1;
    this.loadBuilding(this.currentParcel);
  }

  removeFloorLevel() {
    if (!this.currentParcel) return;
    const building = this.currentParcel.building;
    if (building.floors.length <= 2) {
      alert("Cannot remove base structural ground levels!");
      return;
    }
    building.floors.pop();
    building.totalFloors -= 1;
    this.loadBuilding(this.currentParcel);
  }

  splitActiveUnit() {
    if (!this.selectedMesh || !this.selectedMesh.userData) return;
    const unit = this.selectedMesh.userData.unitData;
    const floor = this.selectedMesh.userData.floorData;
    if (!floor || floor.units.length >= 4) {
      alert("Maximum unit subdivision limit (4 units per floor) reached.");
      return;
    }

    const newUnitNo = `${unit.unitNo}B`;
    unit.unitNo = `${unit.unitNo}A`;
    unit.carpetAreaSqM = Math.round(unit.carpetAreaSqM / 2);
    unit.udsSqM = parseFloat((unit.udsSqM / 2).toFixed(2));
    unit.ulpin3d = `${this.currentParcel.surfaceUlpin}-BA-${floor.floorCode}-${unit.unitNo}`;

    const splitUnit = {
      ...unit,
      unitNo: newUnitNo,
      ulpin3d: `${this.currentParcel.surfaceUlpin}-BA-${floor.floorCode}-${newUnitNo}`,
      owner: "Subdivided Title Holder B",
      aadhaarMasked: "XXXX-XXXX-8822",
      status: "Registered"
    };

    floor.units.push(splitUnit);
    this.loadBuilding(this.currentParcel);
  }

  setColorMode(mode) {
    this.colorMode = mode;
    this.unitMeshes.forEach(mesh => {
      const unit = mesh.userData.unitData;
      const floor = mesh.userData.floorData;
      const newCol = this.getUnitColor(unit, floor);
      mesh.userData.originalColor = newCol;
      mesh.material.color.setHex(newCol);
    });
  }

  selectFloorByIndex(floorIndex) {
    const targetGroup = this.floorMeshes.find(fg => fg.userData.floorIndex === floorIndex);
    if (!targetGroup) return;

    // Pick first unit of this floor
    const firstUnit = targetGroup.children.find(child => child.userData && child.userData.type === 'unit');
    if (firstUnit) {
      this.handleSelectUnit(firstUnit);
    }
  }

  handleSelectUnit(mesh) {
    if (this.selectedMesh && this.selectedMesh !== mesh) {
      this.selectedMesh.material.emissive.setHex(0x000000);
    }

    this.selectedMesh = mesh;
    this.selectedMesh.material.emissive.setHex(0x3b82f6);
    this.selectedMesh.material.emissiveIntensity = 0.45;

    if (this.onSelectCallback) {
      this.onSelectCallback(mesh.userData.unitData, mesh.userData.floorData, mesh.userData.parcelData);
    }
  }

  focusCamera(viewPreset = 'iso') {
    if (viewPreset === 'iso') {
      gsapTo(this.camera.position, { x: 34, y: 26, z: 42, duration: 1 });
      gsapTo(this.controls.target, { x: 0, y: 6, z: 0, duration: 1 });
    } else if (viewPreset === 'top') {
      gsapTo(this.camera.position, { x: 0, y: 55, z: 0.1, duration: 1 });
      gsapTo(this.controls.target, { x: 0, y: 0, z: 0, duration: 1 });
    } else if (viewPreset === 'street') {
      gsapTo(this.camera.position, { x: 26, y: 3, z: 26, duration: 1 });
      gsapTo(this.controls.target, { x: 0, y: 5, z: 0, duration: 1 });
    }
  }

  setupEvents() {
    window.addEventListener('resize', () => this.onResize());

    const canvasEl = this.renderer.domElement;

    canvasEl.addEventListener('mousemove', (e) => {
      const rect = canvasEl.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      this.raycaster.setFromCamera(this.mouse, this.camera);
      const intersects = this.raycaster.intersectObjects(this.unitMeshes);

      if (intersects.length > 0) {
        canvasEl.style.cursor = 'pointer';
        const hit = intersects[0].object;
        if (this.hoveredMesh && this.hoveredMesh !== hit && this.hoveredMesh !== this.selectedMesh) {
          this.hoveredMesh.material.emissive.setHex(0x000000);
        }
        this.hoveredMesh = hit;
        if (this.hoveredMesh !== this.selectedMesh) {
          this.hoveredMesh.material.emissive.setHex(0x60a5fa);
          this.hoveredMesh.material.emissiveIntensity = 0.25;
        }
      } else {
        canvasEl.style.cursor = 'default';
        if (this.hoveredMesh && this.hoveredMesh !== this.selectedMesh) {
          this.hoveredMesh.material.emissive.setHex(0x000000);
        }
        this.hoveredMesh = null;
      }
    });

    canvasEl.addEventListener('click', (e) => {
      const rect = canvasEl.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      this.raycaster.setFromCamera(this.mouse, this.camera);
      const intersects = this.raycaster.intersectObjects(this.unitMeshes);

      if (intersects.length > 0) {
        this.handleSelectUnit(intersects[0].object);
      }
    });
  }

  onResize() {
    if (!this.container || !this.renderer) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }
}

// Simple tween helper without heavy external lib
function gsapTo(target, opts) {
  const startX = target.x;
  const startY = target.y;
  const startZ = target.z;
  const targetX = opts.x !== undefined ? opts.x : startX;
  const targetY = opts.y !== undefined ? opts.y : startY;
  const targetZ = opts.z !== undefined ? opts.z : startZ;
  const duration = (opts.duration || 1) * 1000;
  const startTime = performance.now();

  function step(time) {
    const elapsed = time - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const ease = 0.5 - Math.cos(progress * Math.PI) / 2; // in-out sine

    target.x = startX + (targetX - startX) * ease;
    target.y = startY + (targetY - startY) * ease;
    target.z = startZ + (targetZ - startZ) * ease;

    if (progress < 1) {
      requestAnimationFrame(step);
    }
  }
  requestAnimationFrame(step);
}
