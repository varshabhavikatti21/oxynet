// Realistic Indian Cadastral & 3D Vertical Property Dataset for SIH26011
// Compliant with DILRMP (Digital India Land Records Modernization Programme) & DoLR (Dept of Land Resources)

const ULPIN_DATASET = {
  cities: [
    {
      id: "blr",
      name: "Bengaluru Urban (Karnataka)",
      stateCode: "29", // Karnataka
      distCode: "01",  // Bengaluru Urban
      talukCode: "04", // KR Puram / Mahadevapura
      villageCode: "002819", // Whitefield
      center: [12.9698, 77.7499],
      zoom: 17
    },
    {
      id: "hyd",
      name: "Hyderabad (Telangana)",
      stateCode: "36", // Telangana
      distCode: "05",  // Hyderabad
      talukCode: "02", // Serilingampally
      villageCode: "001402", // HITEC City / Madhapur
      center: [17.4474, 78.3762],
      zoom: 17
    },
    {
      id: "del",
      name: "New Delhi (NCT)",
      stateCode: "07", // Delhi
      distCode: "01",  // New Delhi
      talukCode: "03", // Chanakyapuri / Connaught
      villageCode: "000108", // Barakhamba
      center: [28.6289, 77.2195],
      zoom: 17
    }
  ],

  parcels: [
    {
      id: "PARCEL-KA-001",
      cityId: "blr",
      surveyNo: "142/2A",
      kathaNo: "K-992014",
      locality: "Prestige Cyber Towers, ITPL Main Rd, Whitefield",
      polygon: [
        [12.9705, 77.7490],
        [12.9712, 77.7505],
        [12.9698, 77.7512],
        [12.9691, 77.7497]
      ],
      surfaceUlpin: "29010400281901",
      landUse: "Commercial / IT Hub",
      totalSurfaceAreaSqM: 4850,
      sanctionedFAR: 3.5,
      actualFAR: 3.42,
      totalUnits: 18,
      baseElevationMsl: 920.0, // Mean Sea Level
      building: {
        name: "Cyber Heights Tower Alpha",
        structureType: "RCC High-Rise Mixed Use",
        block: "A",
        totalFloors: 6, // 2 basement + ground + 3 tower floors for clean 3D rendering
        basementCount: 2,
        podiumCount: 1,
        towerHeightM: 32.5,
        floors: [
          {
            floorIndex: -2,
            floorCode: "B02",
            name: "Basement Level 2 (Deep Parking)",
            elevationOffsetM: -6.0,
            heightM: 3.0,
            areaSqM: 4200,
            useType: "Sub-Surface Parking & Utility",
            units: [
              {
                unitNo: "P-B2-01",
                ulpin3d: "29010400281901-BA-FB02-UPB201",
                owner: "Prestige Facilities Mgmt Ltd",
                aadhaarMasked: "XXXX-XXXX-8921",
                type: "Reserved Parking Bay (Slots 1-40)",
                carpetAreaSqM: 650,
                udsSqM: 0,
                status: "Registered",
                mortgage: "No Encumbrance",
                color: "#475569",
                zMin: -6.0,
                zMax: -3.0
              },
              {
                unitNo: "UTIL-B2-02",
                ulpin3d: "29010400281901-BA-FB02-UU002",
                owner: "Bescom Sub-station & Water Sump (Common)",
                aadhaarMasked: "GOVT-COMMON",
                type: "Common Infrastructure",
                carpetAreaSqM: 800,
                udsSqM: 0,
                status: "Government/Common",
                mortgage: "Exempted",
                color: "#64748b",
                zMin: -6.0,
                zMax: -3.0
              }
            ]
          },
          {
            floorIndex: -1,
            floorCode: "B01",
            name: "Basement Level 1 (HVAC & EV Hub)",
            elevationOffsetM: -3.0,
            heightM: 3.0,
            areaSqM: 4200,
            useType: "Commercial Parking & EV Hub",
            units: [
              {
                unitNo: "P-B1-01",
                ulpin3d: "29010400281901-BA-FB01-UPB101",
                owner: "Tata Power EV Fast-Charge Infra",
                aadhaarMasked: "XXXX-XXXX-3341",
                type: "Commercial EV Station",
                carpetAreaSqM: 420,
                udsSqM: 45.2,
                status: "Registered",
                mortgage: "Leased (15 Yrs)",
                color: "#059669",
                zMin: -3.0,
                zMax: 0.0
              }
            ]
          },
          {
            floorIndex: 0,
            floorCode: "GF0",
            name: "Ground Floor (Grand Lobby & Retail Arcade)",
            elevationOffsetM: 0.0,
            heightM: 4.5,
            areaSqM: 3800,
            useType: "Commercial Retail",
            units: [
              {
                unitNo: "G-01",
                ulpin3d: "29010400281901-BA-FGF0-UG001",
                owner: "Starbucks Coffee India Pvt Ltd",
                aadhaarMasked: "XXXX-XXXX-1109",
                type: "F&B Retail Outlet",
                carpetAreaSqM: 320,
                udsSqM: 110.5,
                status: "Registered",
                mortgage: "Mortgaged (HDFC Bank)",
                color: "#2563eb",
                zMin: 0.0,
                zMax: 4.5
              },
              {
                unitNo: "G-02",
                ulpin3d: "29010400281901-BA-FGF0-UG002",
                owner: "HDFC Bank Ltd (Retail Branch)",
                aadhaarMasked: "XXXX-XXXX-9981",
                type: "Banking & Financial Services",
                carpetAreaSqM: 480,
                udsSqM: 165.2,
                status: "Registered",
                mortgage: "Clear Title",
                color: "#2563eb",
                zMin: 0.0,
                zMax: 4.5
              }
            ]
          },
          {
            floorIndex: 1,
            floorCode: "L01",
            name: "1st Floor (Co-Working Hub & Labs)",
            elevationOffsetM: 4.5,
            heightM: 3.8,
            areaSqM: 3600,
            useType: "IT Workspace",
            units: [
              {
                unitNo: "Unit-101",
                ulpin3d: "29010400281901-BA-FL01-U101",
                owner: "Infosys Cloud Solutions Unit",
                aadhaarMasked: "XXXX-XXXX-4490",
                type: "Enterprise Office Space",
                carpetAreaSqM: 1200,
                udsSqM: 410.0,
                status: "Registered",
                mortgage: "Clear Title",
                color: "#16a34a",
                zMin: 4.5,
                zMax: 8.3
              },
              {
                unitNo: "Unit-102",
                ulpin3d: "29010400281901-BA-FL01-U102",
                owner: "Suresh Kumar & Ramesh Verma",
                aadhaarMasked: "XXXX-XXXX-7723",
                type: "Fintech Startup Incubator",
                carpetAreaSqM: 950,
                udsSqM: 325.0,
                status: "Disputed",
                mortgage: "Civil Court Stay Order OS/2025/11",
                color: "#dc2626",
                zMin: 4.5,
                zMax: 8.3
              }
            ]
          },
          {
            floorIndex: 2,
            floorCode: "L02",
            name: "2nd Floor (Executive Suites)",
            elevationOffsetM: 8.3,
            heightM: 3.8,
            areaSqM: 3600,
            useType: "IT Workspace",
            units: [
              {
                unitNo: "Unit-201",
                ulpin3d: "29010400281901-BA-FL02-U201",
                owner: "Aarav Sharma & Priya Sharma",
                aadhaarMasked: "XXXX-XXXX-5521",
                type: "Corporate Headquarters",
                carpetAreaSqM: 1500,
                udsSqM: 512.4,
                status: "Registered",
                mortgage: "Mortgaged (SBI Home & Comm Loans)",
                color: "#2563eb",
                zMin: 8.3,
                zMax: 12.1
              },
              {
                unitNo: "Unit-202",
                ulpin3d: "29010400281901-BA-FL02-U202",
                owner: "Under Transfer (Seller: K. Raman)",
                aadhaarMasked: "XXXX-XXXX-1902",
                type: "Office Suite",
                carpetAreaSqM: 820,
                udsSqM: 280.1,
                status: "Pending Mutation",
                mortgage: "NOC Verification Stage",
                color: "#d97706",
                zMin: 8.3,
                zMax: 12.1
              }
            ]
          },
          {
            floorIndex: 3,
            floorCode: "L03",
            name: "3rd Floor (Penthouse & Sky Terrace)",
            elevationOffsetM: 12.1,
            heightM: 4.2,
            areaSqM: 3400,
            useType: "Sky Lounge & Terrace Club",
            units: [
              {
                unitNo: "PH-301",
                ulpin3d: "29010400281901-BA-FL03-UPH301",
                owner: "Meera Krishnan",
                aadhaarMasked: "XXXX-XXXX-6610",
                type: "Luxury Sky Suite & Terrace",
                carpetAreaSqM: 980,
                udsSqM: 335.0,
                status: "Registered",
                mortgage: "Clear Title",
                color: "#16a34a",
                zMin: 12.1,
                zMax: 16.3
              }
            ]
          }
        ]
      }
    },

    {
      id: "PARCEL-HYD-002",
      cityId: "hyd",
      surveyNo: "68/Part",
      kathaNo: "HYD-772910",
      locality: "Aparna Sky Tower, Financial District, Gachibowli",
      polygon: [
        [17.4485, 78.3750],
        [17.4492, 78.3768],
        [17.4478, 78.3775],
        [17.4470, 78.3758]
      ],
      surfaceUlpin: "36050200140203",
      landUse: "High-Density Residential Multi-Storey",
      totalSurfaceAreaSqM: 6200,
      sanctionedFAR: 4.0,
      actualFAR: 3.88,
      totalUnits: 24,
      baseElevationMsl: 545.0,
      building: {
        name: "Aparna Zenith Vertical Enclave",
        structureType: "High-Rise Smart Residential Complex",
        block: "B",
        totalFloors: 5,
        basementCount: 1,
        podiumCount: 1,
        towerHeightM: 28.0,
        floors: [
          {
            floorIndex: -1,
            floorCode: "B01",
            name: "Basement Parking & EV Stalls",
            elevationOffsetM: -3.5,
            heightM: 3.5,
            areaSqM: 5800,
            useType: "Resident Parking Area",
            units: [
              {
                unitNo: "P-RES-01",
                ulpin3d: "36050200140203-BB-FB01-UP001",
                owner: "Aparna Apartment Owners Welfare Assoc.",
                aadhaarMasked: "SOCIETY-REG-44",
                type: "Common Parking Bays",
                carpetAreaSqM: 2200,
                udsSqM: 0,
                status: "Government/Common",
                mortgage: "No Encumbrance",
                color: "#64748b",
                zMin: -3.5,
                zMax: 0.0
              }
            ]
          },
          {
            floorIndex: 0,
            floorCode: "GF0",
            name: "Ground Level (Clubhouse & Amenities)",
            elevationOffsetM: 0.0,
            heightM: 4.0,
            areaSqM: 5200,
            useType: "Community & Recreation",
            units: [
              {
                unitNo: "CLUB-01",
                ulpin3d: "36050200140203-BB-FGF0-UCLUB1",
                owner: "Zenith Resident Welfare Association",
                aadhaarMasked: "SOCIETY-REG-44",
                type: "Clubhouse / Gymnasium / Infinity Lounge",
                carpetAreaSqM: 1800,
                udsSqM: 0,
                status: "Government/Common",
                mortgage: "Clear Title",
                color: "#0284c7",
                zMin: 0.0,
                zMax: 4.0
              }
            ]
          },
          {
            floorIndex: 1,
            floorCode: "F01",
            name: "1st Residential Floor",
            elevationOffsetM: 4.0,
            heightM: 3.2,
            areaSqM: 4800,
            useType: "Residential Flats",
            units: [
              {
                unitNo: "Flat-101",
                ulpin3d: "36050200140203-BB-FF01-U101",
                owner: "Vikramaditya Reddy & Ananya Reddy",
                aadhaarMasked: "XXXX-XXXX-7128",
                type: "3BHK Premium Residential",
                carpetAreaSqM: 185,
                udsSqM: 52.3,
                status: "Registered",
                mortgage: "Mortgaged (ICICI Bank Ltd)",
                color: "#16a34a",
                zMin: 4.0,
                zMax: 7.2
              },
              {
                unitNo: "Flat-102",
                ulpin3d: "36050200140203-BB-FF01-U102",
                owner: "Mohd. Tariq Mansoor",
                aadhaarMasked: "XXXX-XXXX-9844",
                type: "3BHK Premium Residential",
                carpetAreaSqM: 185,
                udsSqM: 52.3,
                status: "Registered",
                mortgage: "Clear Title",
                color: "#16a34a",
                zMin: 4.0,
                zMax: 7.2
              }
            ]
          },
          {
            floorIndex: 2,
            floorCode: "F02",
            name: "2nd Residential Floor",
            elevationOffsetM: 7.2,
            heightM: 3.2,
            areaSqM: 4800,
            useType: "Residential Flats",
            units: [
              {
                unitNo: "Flat-201",
                ulpin3d: "36050200140203-BB-FF02-U201",
                owner: "Deepak Chawla",
                aadhaarMasked: "XXXX-XXXX-3199",
                type: "4BHK Ultra Luxury",
                carpetAreaSqM: 260,
                udsSqM: 73.5,
                status: "Pending Mutation",
                mortgage: "Inheritance Mutation in Progress",
                color: "#d97706",
                zMin: 7.2,
                zMax: 10.4
              },
              {
                unitNo: "Flat-202",
                ulpin3d: "36050200140203-BB-FF02-U202",
                owner: "Government Earmarked Quota (TSIIC)",
                aadhaarMasked: "GOVT-TELANGANA",
                type: "Official Guest Suite",
                carpetAreaSqM: 260,
                udsSqM: 73.5,
                status: "Government/Common",
                mortgage: "Govt Title",
                color: "#0284c7",
                zMin: 7.2,
                zMax: 10.4
              }
            ]
          }
        ]
      }
    },

    {
      id: "PARCEL-DEL-003",
      cityId: "del",
      surveyNo: "12/Block-C",
      kathaNo: "NDMC-2026-918",
      locality: "Statesman House, Barakhamba Rd, Connaught Place",
      polygon: [
        [28.6295, 77.2185],
        [28.6302, 77.2202],
        [28.6288, 77.2209],
        [28.6281, 77.2192]
      ],
      surfaceUlpin: "07010300010807",
      landUse: "Central Commercial / Heritage Zone",
      totalSurfaceAreaSqM: 3900,
      sanctionedFAR: 2.8,
      actualFAR: 2.75,
      totalUnits: 14,
      baseElevationMsl: 215.0,
      building: {
        name: "Capital Plaza Commercial Tower",
        structureType: "Steel Frame Glass Facade",
        block: "C",
        totalFloors: 4,
        basementCount: 1,
        podiumCount: 1,
        towerHeightM: 22.0,
        floors: [
          {
            floorIndex: 0,
            floorCode: "GF0",
            name: "Ground Floor Atrium",
            elevationOffsetM: 0.0,
            heightM: 4.5,
            areaSqM: 3200,
            useType: "Commercial Atrium & Consulate",
            units: [
              {
                unitNo: "C-001",
                ulpin3d: "07010300010807-BC-FGF0-UC001",
                owner: "Delhi Metro Rail Corp (Air Rights Lease)",
                aadhaarMasked: "GOVT-DMRC-99",
                type: "Transit Integration Hub",
                carpetAreaSqM: 600,
                udsSqM: 180.0,
                status: "Government/Common",
                mortgage: "Statutory Public Right",
                color: "#0284c7",
                zMin: 0.0,
                zMax: 4.5
              }
            ]
          },
          {
            floorIndex: 1,
            floorCode: "F01",
            name: "1st Floor Corporate Office",
            elevationOffsetM: 4.5,
            heightM: 4.0,
            areaSqM: 3000,
            useType: "Diplomatic & Legal Chambers",
            units: [
              {
                unitNo: "C-101",
                ulpin3d: "07010300010807-BC-FF01-UC101",
                owner: "Senior Advocate Harish Salve Chambers",
                aadhaarMasked: "XXXX-XXXX-4501",
                type: "Legal Suites",
                carpetAreaSqM: 750,
                udsSqM: 225.0,
                status: "Registered",
                mortgage: "Clear Title",
                color: "#16a34a",
                zMin: 4.5,
                zMax: 8.5
              }
            ]
          }
        ]
      }
    }
  ],

  // Pre-configured mock mutations for transaction demonstration
  mutations: [
    {
      mutationId: "MUT-2026-KA-8819",
      ulpin3d: "29010400281901-BA-FL02-U202",
      propertyDesc: "Cyber Heights Tower Alpha, Block A, Floor 2, Unit-202",
      seller: "K. Raman (PAN: AABPR****G)",
      buyer: "NexGen Cloud Services LLP",
      applicationDate: "2026-08-28",
      status: "In Scrutiny / Sub-Registrar",
      currentStage: 3,
      stages: [
        { name: "Application Submitted & e-Fee Paid", status: "completed", date: "2026-08-28" },
        { name: "DigiLocker Title Deed & Encumbrance Verified", status: "completed", date: "2026-08-30" },
        { name: "3D Volumetric Boundary & UDS Validation", status: "in-progress", date: "2026-09-05" },
        { name: "Sub-Registrar Digital Sign & 3D ULPIN Issuance", status: "pending", date: "Est. 2026-09-15" }
      ],
      feeAmount: "₹ 1,45,200",
      stampDuty: "₹ 6,80,000"
    },
    {
      mutationId: "MUT-2026-TS-5541",
      ulpin3d: "36050200140203-BB-FF02-U201",
      propertyDesc: "Aparna Zenith, Block B, Floor 2, Flat-201",
      seller: "Late Sh. Harish Chawla (Inheritance)",
      buyer: "Deepak Chawla (Legal Heir)",
      applicationDate: "2026-09-02",
      status: "30-Day Public Notice Period",
      currentStage: 2,
      stages: [
        { name: "Succession Certificate Uploaded", status: "completed", date: "2026-09-02" },
        { name: "3D Cadastral Footprint Audit", status: "completed", date: "2026-09-04" },
        { name: "Public Objection Window (15/30 Days)", status: "in-progress", date: "Active" },
        { name: "Final Mutation in Bhu-Aadhaar 3D Registry", status: "pending", date: "Est. 2026-10-02" }
      ],
      feeAmount: "₹ 15,000",
      stampDuty: "Exempted (Inheritance)"
    }
  ],

  // DigiLocker Documents template
  digiLockerRecords: {
    "29010400281901-BA-FL01-U101": [
      {
        id: "DOC-DL-01",
        docType: "Registered Sale Deed (Kaveri 2.0)",
        issueAuth: "Department of Stamps & Registration, Govt of Karnataka",
        docNo: "KVR/KRP/4491/2023-24",
        issueDate: "14-Nov-2023",
        status: "Digitally Verified",
        hash: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
      },
      {
        id: "DOC-DL-02",
        docType: "E-Khata Certificate (BBMP / e-Aasthi)",
        issueAuth: "Bruhat Bengaluru Mahanagara Palike",
        docNo: "BBMP/E-KH/991028/2024",
        issueDate: "02-Feb-2024",
        status: "Digitally Verified",
        hash: "7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069"
      },
      {
        id: "DOC-DL-03",
        docType: "Nil-Encumbrance Certificate (Form 15)",
        issueAuth: "Sub-Registrar KR Puram",
        docNo: "EC-2026-091823",
        issueDate: "01-Sep-2026",
        status: "Zero Encumbrance Valid",
        hash: "bc472506e6761922c159892697858c49dc75f9fe7ff330541165a0b73c9f28d8"
      },
      {
        id: "DOC-DL-04",
        docType: "Occupancy Certificate (OC) & Fire Safety NOC",
        issueAuth: "Karnataka State Fire & Emergency Services / BBMP",
        docNo: "FES/NOC/BLR-EAST/2023",
        issueDate: "18-Oct-2023",
        status: "Digitally Verified",
        hash: "82a921d1b32d207d8c0b240b991873fb2a95c8ba1116c4f0ff462e0efe9b1fcf"
      }
    ]
  }
};
