/**
 * Main Controller Application for SIH26011 - 3D ULPIN Vertical Property Mapping System
 */

let viewer3D = null;
let gisMap = null;
let currentActiveUnit = null;
let currentActiveParcel = null;

document.addEventListener('DOMContentLoaded', () => {
  initUI();
  init3DViewer();
  initGisMap();
  initDashboard();
  initGenerator();
  initMutations();
  initDigiLocker();
  initLiveClock();
});

// 1. Navigation Tab Switching
function initUI() {
  const navButtons = document.querySelectorAll('.nav-tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');

  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');

      navButtons.forEach(b => b.classList.remove('active'));
      tabPanes.forEach(pane => pane.classList.remove('active'));

      btn.classList.add('active');
      const activePane = document.getElementById(`tab-${targetTab}`);
      if (activePane) {
        activePane.classList.add('active');
      }

      // Trigger redraws if switching to map or 3d
      if (targetTab === 'map' && gisMap) {
        gisMap.invalidateSize();
      } else if (targetTab === '3d' && viewer3D) {
        viewer3D.onResize();
      }
    });
  });

  // Global search input
  const searchInput = document.getElementById('global-search-input');
  if (searchInput) {
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        handleGlobalSearch(searchInput.value.trim());
      }
    });
  }
}

// 2. Three.js 3D Viewer Initializer
function init3DViewer() {
  const container = document.getElementById('three-canvas-container');
  if (!container) return;

  viewer3D = new ULPIN3DViewer('three-canvas-container', (unit, floor, parcel) => {
    updateSidebarInfo(unit, floor, parcel);
  });

  // Load default parcel
  const defaultParcel = ULPIN_DATASET.parcels[0];
  currentActiveParcel = defaultParcel;
  viewer3D.loadBuilding(defaultParcel);
  populateBuildingSelector();
  populateFloorList(defaultParcel);

  // Auto-select first unit
  const firstFloor = defaultParcel.building.floors[2]; // Ground floor
  const firstUnit = firstFloor.units[0];
  updateSidebarInfo(firstUnit, firstFloor, defaultParcel);

  // Controls bindings
  const explodeSlider = document.getElementById('explode-slider');
  if (explodeSlider) {
    explodeSlider.addEventListener('input', (e) => {
      viewer3D.setExplode(e.target.value);
    });
  }

  const xrayToggle = document.getElementById('xray-toggle-btn');
  if (xrayToggle) {
    xrayToggle.addEventListener('click', () => {
      const active = xrayToggle.classList.toggle('active');
      viewer3D.setXRay(active);
    });
  }

  const subToggle = document.getElementById('subsurface-toggle-btn');
  if (subToggle) {
    subToggle.addEventListener('click', () => {
      const active = subToggle.classList.toggle('active');
      viewer3D.setSubSurface(active);
    });
  }

  const arToggle = document.getElementById('ar-toggle-btn');
  if (arToggle) {
    arToggle.addEventListener('click', () => {
      const active = arToggle.classList.toggle('active');
      viewer3D.setARSpatial(active);
    });
  }

  // Color Mode buttons
  const modeBtns = document.querySelectorAll('.mode-pill-btn');
  modeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      modeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const mode = btn.getAttribute('data-mode');
      viewer3D.setColorMode(mode);
    });
  });

  // Time of Day buttons
  const timeBtns = document.querySelectorAll('.time-pill-btn');
  timeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      timeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const timeMode = btn.getAttribute('data-time');
      viewer3D.setTimeOfDay(timeMode);
    });
  });

  // AI Compliance Scanner Button
  const btnScanner = document.getElementById('btn-ai-scanner');
  if (btnScanner) {
    btnScanner.addEventListener('click', () => {
      runAIComplianceScan();
    });
  }

  // Camera Presets
  const btnIso = document.getElementById('cam-iso');
  const btnTop = document.getElementById('cam-top');
  const btnStreet = document.getElementById('cam-street');

  if (btnIso) btnIso.addEventListener('click', () => viewer3D.focusCamera('iso'));
  if (btnTop) btnTop.addEventListener('click', () => viewer3D.focusCamera('top'));
  if (btnStreet) btnStreet.addEventListener('click', () => viewer3D.focusCamera('street'));

  // Building selector change
  const bldgSelect = document.getElementById('building-selector');
  if (bldgSelect) {
    bldgSelect.addEventListener('change', (e) => {
      const selectedParcel = ULPIN_DATASET.parcels.find(p => p.id === e.target.value);
      if (selectedParcel) {
        currentActiveParcel = selectedParcel;
        viewer3D.loadBuilding(selectedParcel);
        populateFloorList(selectedParcel);
        const gFloor = selectedParcel.building.floors.find(f => f.floorIndex === 0) || selectedParcel.building.floors[0];
        updateSidebarInfo(gFloor.units[0], gFloor, selectedParcel);
      }
    });
  }
}

function populateBuildingSelector() {
  const select = document.getElementById('building-selector');
  if (!select) return;
  select.innerHTML = '';
  ULPIN_DATASET.parcels.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = `${p.building.name} (${p.surveyNo})`;
    select.appendChild(opt);
  });
}

function populateFloorList(parcel) {
  const listContainer = document.getElementById('floor-selector-list');
  if (!listContainer) return;
  listContainer.innerHTML = '';

  parcel.building.floors.slice().reverse().forEach(floor => {
    const btn = document.createElement('button');
    btn.className = 'floor-item-btn';
    btn.innerHTML = `
      <span><strong>${floor.floorCode}</strong>: ${floor.name.split('(')[0]}</span>
      <span style="font-family: monospace; font-size: 0.7rem; color: #38bdf8;">${floor.elevationOffsetM >= 0 ? '+' : ''}${floor.elevationOffsetM}m</span>
    `;
    btn.addEventListener('click', () => {
      document.querySelectorAll('.floor-item-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      viewer3D.selectFloorByIndex(floor.floorIndex);
    });
    listContainer.appendChild(btn);
  });
}

// 3. Update Sidebar HUD Info
function updateSidebarInfo(unit, floor, parcel) {
  currentActiveUnit = unit;
  currentActiveParcel = parcel;

  // Title and Status
  document.getElementById('hud-unit-title').textContent = `${unit.unitNo} — ${floor.name.split('(')[0]}`;
  const statusBadge = document.getElementById('hud-unit-status');
  statusBadge.textContent = unit.status;
  statusBadge.className = 'status-badge';
  if (unit.status === 'Registered') statusBadge.classList.add('registered');
  else if (unit.status === 'Disputed') statusBadge.classList.add('disputed');
  else if (unit.status === 'Pending Mutation') statusBadge.classList.add('pending');
  else statusBadge.classList.add('common');

  // 3D ULPIN Code
  document.getElementById('hud-3d-ulpin').textContent = unit.ulpin3d;

  // Specs
  document.getElementById('hud-owner').textContent = unit.owner;
  document.getElementById('hud-aadhaar').textContent = unit.aadhaarMasked;
  document.getElementById('hud-carpet-area').textContent = `${unit.carpetAreaSqM} sq.m`;
  document.getElementById('hud-uds').textContent = `${unit.udsSqM} sq.m (${((unit.udsSqM / parcel.totalSurfaceAreaSqM) * 100).toFixed(2)}%)`;
  document.getElementById('hud-z-extent').textContent = `${unit.zMin >= 0 ? '+' : ''}${unit.zMin}m to ${unit.zMax >= 0 ? '+' : ''}${unit.zMax}m AGL`;
  document.getElementById('hud-msl-elevation').textContent = `${parcel.baseElevationMsl + unit.zMin}m MSL`;
  document.getElementById('hud-mortgage').textContent = unit.mortgage;
  document.getElementById('hud-landuse').textContent = parcel.landUse;
}

// 4. GIS Map Initializer
function initGisMap() {
  gisMap = new ULPINGisMap('leaflet-map', (parcelId) => {
    // Switch to 3D tab and load parcel
    const parcel = ULPIN_DATASET.parcels.find(p => p.id === parcelId);
    if (parcel) {
      document.querySelector('[data-tab="3d"]').click();
      document.getElementById('building-selector').value = parcelId;
      viewer3D.loadBuilding(parcel);
      populateFloorList(parcel);
    }
  });

  // City selector in map
  const citySelect = document.getElementById('map-city-select');
  if (citySelect) {
    citySelect.addEventListener('change', (e) => {
      gisMap.flyToCity(e.target.value);
    });
  }

  // Metro layer toggle
  const metroCheck = document.getElementById('toggle-metro-layer');
  if (metroCheck) {
    metroCheck.addEventListener('change', (e) => {
      gisMap.toggleMetroLayer(e.target.checked);
    });
  }

  // Map Basemap Selector
  const basemapSelect = document.getElementById('map-basemap-select');
  if (basemapSelect) {
    basemapSelect.addEventListener('change', (e) => {
      gisMap.setBasemapTile(e.target.value);
    });
  }

  // Cadastral Map Place Search
  const mapSearchInput = document.getElementById('map-place-search-input');
  const btnMapSearch = document.getElementById('btn-map-search-place');

  if (btnMapSearch && mapSearchInput) {
    btnMapSearch.addEventListener('click', () => {
      gisMap.searchPlace(mapSearchInput.value);
    });

    mapSearchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        gisMap.searchPlace(mapSearchInput.value);
      }
    });
  }

  // Quick Chips
  const quickChips = document.querySelectorAll('.quick-chip');
  quickChips.forEach(chip => {
    chip.addEventListener('click', () => {
      const q = chip.getAttribute('data-query');
      if (mapSearchInput) mapSearchInput.value = q;
      gisMap.searchPlace(q);
    });
  });

  // Draw Custom Parcel Button
  const drawBtn = document.getElementById('btn-draw-parcel');
  if (drawBtn) {
    drawBtn.addEventListener('click', () => {
      gisMap.startDrawCustomParcel();
    });
  }

  // Building Customizer Buttons
  const btnAddFloor = document.getElementById('btn-add-floor');
  const btnRemoveFloor = document.getElementById('btn-remove-floor');
  const btnSplitUnit = document.getElementById('btn-split-unit');
  const btnCalcTax = document.getElementById('btn-calc-tax');

  if (btnAddFloor) btnAddFloor.addEventListener('click', () => { viewer3D.addFloorLevel(); populateFloorList(currentActiveParcel); });
  if (btnRemoveFloor) btnRemoveFloor.addEventListener('click', () => { viewer3D.removeFloorLevel(); populateFloorList(currentActiveParcel); });
  if (btnSplitUnit) btnSplitUnit.addEventListener('click', () => { viewer3D.splitActiveUnit(); populateFloorList(currentActiveParcel); });
  if (btnCalcTax) btnCalcTax.addEventListener('click', () => calculatePropertyTax());

  // SIH Guided Demo Tour Controls
  const btnStartTour = document.getElementById('btn-start-demo-tour');
  const btnNextStep = document.getElementById('btn-next-tour-step');
  const btnStopTour = document.getElementById('btn-stop-tour');

  if (btnStartTour) btnStartTour.addEventListener('click', startDemoTour);
  if (btnNextStep) btnNextStep.addEventListener('click', nextTourStep);
  if (btnStopTour) btnStopTour.addEventListener('click', stopDemoTour);
}

// 5. Dashboard Tab & Interactive Chart.js Visualizations
function initDashboard() {
  const container = document.getElementById('dashboard-activity-list');
  if (container) {
    const activities = [
      { type: 'mutation', desc: 'Mutation approved for 3D ULPIN: 29010400281901-BA-FL01-U101 (Infosys Cloud)', time: '12 mins ago', color: '#10b981' },
      { type: 'dispute', desc: 'Dispute Flagged on Survey 142/2A, Unit-102 (Civil Court Stay Order)', time: '1 hr ago', color: '#ef4444' },
      { type: 'bhu', desc: '3D Bhu-Aadhaar Deed generated for Aparna Zenith Flat-101', time: '3 hrs ago', color: '#38bdf8' },
      { type: 'scan', desc: 'LiDAR LoD3 Point Cloud ingested for Connaught Place Sector C', time: '5 hrs ago', color: '#f59e0b' }
    ];

    container.innerHTML = activities.map(act => `
      <div class="activity-item">
        <div class="activity-dot" style="background: ${act.color};"></div>
        <div>
          <div class="activity-desc">${act.desc}</div>
          <div class="activity-time">${act.time}</div>
        </div>
      </div>
    `).join('');
  }

  // Initialize Chart.js Charts if canvas exists
  if (typeof Chart !== 'undefined') {
    initDashboardCharts();
  }
}

function initDashboardCharts() {
  // 1. Land Use Distribution (Doughnut)
  const ctxLand = document.getElementById('chart-landuse');
  if (ctxLand) {
    new Chart(ctxLand, {
      type: 'doughnut',
      data: {
        labels: ['Commercial / IT', 'Residential Suites', 'Parking & Utility Z', 'Govt & Common UDS'],
        datasets: [{
          data: [48, 32, 12, 8],
          backgroundColor: ['#2563eb', '#10b981', '#475569', '#38bdf8'],
          borderColor: '#111827',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { color: '#9ca3af', font: { size: 11 } } }
        }
      }
    });
  }

  // 2. Mutation TAT Reduction (Line)
  const ctxTat = document.getElementById('chart-tat');
  if (ctxTat) {
    new Chart(ctxTat, {
      type: 'line',
      data: {
        labels: ['2021 (2D Manual)', '2022 (e-Sub Registrar)', '2023 (ULPIN v1)', '2024 (Pilot 3D)', '2026 (Bhu-Aadhaar 3D)'],
        datasets: [{
          label: 'Average Mutation Turnaround Time (Days)',
          data: [48, 32, 21, 11, 4.2],
          borderColor: '#f97316',
          backgroundColor: 'rgba(249, 115, 22, 0.12)',
          fill: true,
          tension: 0.35,
          pointBackgroundColor: '#f97316',
          pointRadius: 5
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: { grid: { color: 'rgba(255,255,255,0.06)' }, ticks: { color: '#9ca3af' } },
          x: { grid: { color: 'rgba(255,255,255,0.06)' }, ticks: { color: '#9ca3af' } }
        },
        plugins: {
          legend: { labels: { color: '#e2e8f0', font: { size: 11 } } }
        }
      }
    });
  }

  // 3. Citywise 3D Density (Bar)
  const ctxCity = document.getElementById('chart-city-density');
  if (ctxCity) {
    new Chart(ctxCity, {
      type: 'bar',
      data: {
        labels: ['Bengaluru Urban', 'Hyderabad HITEC', 'Delhi (Connaught)', 'Mumbai BKC', 'Pune Hinjewadi'],
        datasets: [{
          label: '3D Units Registered',
          data: [6420, 4890, 2350, 1840, 1120],
          backgroundColor: '#3b82f6',
          borderRadius: 6
        }, {
          label: 'Dispute Free %',
          data: [96, 94, 91, 88, 93],
          backgroundColor: '#10b981',
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: { grid: { color: 'rgba(255,255,255,0.06)' }, ticks: { color: '#9ca3af' } },
          x: { grid: { color: 'rgba(255,255,255,0.06)' }, ticks: { color: '#9ca3af' } }
        },
        plugins: {
          legend: { position: 'bottom', labels: { color: '#9ca3af', font: { size: 11 } } }
        }
      }
    });
  }
}

// 6. 3D ULPIN Generator Engine
function initGenerator() {
  const genBtn = document.getElementById('btn-generate-ulpin');
  if (!genBtn) return;

  genBtn.addEventListener('click', () => {
    const state = document.getElementById('gen-state').value;
    const district = document.getElementById('gen-dist').value;
    const tehsil = document.getElementById('gen-tehsil').value;
    const village = document.getElementById('gen-village').value;
    const parcelNo = document.getElementById('gen-parcel').value;
    const block = document.getElementById('gen-block').value;
    const floor = document.getElementById('gen-floor').value;
    const unit = document.getElementById('gen-unit').value;
    const zMin = document.getElementById('gen-zmin').value;
    const zMax = document.getElementById('gen-zmax').value;

    // 14-digit Surface ULPIN: State(2) + Dist(2) + Tehsil(2) + Village(6) + Parcel(2)
    const surface = `${state}${district}${tehsil}${village}${parcelNo.padStart(2, '0')}`;
    // 3D Vertical Extension: Surface - Block - Floor - Unit
    const ulpin3D = `${surface}-B${block}-F${floor}-U${unit}`;

    document.getElementById('gen-output-ulpin').textContent = ulpin3D;
    document.getElementById('gen-output-surface').textContent = surface;
    document.getElementById('gen-output-z').textContent = `[+${zMin}.0m to +${zMax}.0m AGL] (Volume: ${(Math.abs(zMax - zMin) * 120).toFixed(1)} m³) `;
    document.getElementById('gen-output-box').style.display = 'block';
  });
}

// 7. Mutations Management Tab
function initMutations() {
  const container = document.getElementById('mutation-list-container');
  if (!container) return;

  container.innerHTML = ULPIN_DATASET.mutations.map(mut => `
    <div class="mutation-card">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem;">
        <div>
          <span style="font-family: monospace; font-size: 0.75rem; color: #f97316; font-weight: 700;">${mut.mutationId}</span>
          <h3 style="font-size: 1rem; margin-top: 2px;">${mut.propertyDesc}</h3>
        </div>
        <span class="status-badge pending">${mut.status}</span>
      </div>

      <div style="font-family: monospace; font-size: 0.78rem; background: #0b0f19; padding: 6px 10px; border-radius: 4px; color: #60a5fa; margin-bottom: 1rem;">
        3D ULPIN: ${mut.ulpin3d}
      </div>

      <div class="spec-grid" style="margin-bottom: 1rem;">
        <div class="spec-card">
          <div class="spec-label">Transferor (Seller)</div>
          <div class="spec-value" style="font-size: 0.75rem;">${mut.seller}</div>
        </div>
        <div class="spec-card">
          <div class="spec-label">Transferee (Buyer)</div>
          <div class="spec-value" style="font-size: 0.75rem; color: #10b981;">${mut.buyer}</div>
        </div>
        <div class="spec-card">
          <div class="spec-label">e-Stamp Duty</div>
          <div class="spec-value" style="font-size: 0.75rem;">${mut.stampDuty}</div>
        </div>
        <div class="spec-card">
          <div class="spec-label">Application Date</div>
          <div class="spec-value" style="font-size: 0.75rem;">${mut.applicationDate}</div>
        </div>
      </div>

      <div class="timeline">
        ${mut.stages.map(st => `
          <div class="timeline-step ${st.status}">
            <div class="timeline-dot"></div>
            <div class="step-title">${st.name}</div>
            <div class="step-meta">${st.date}</div>
          </div>
        `).join('')}
      </div>

      <button class="btn-primary" style="width: 100%; margin-top: 0.75rem;" onclick="simulateApproveMutation('${mut.mutationId}')">
        ✓ Verify & Digital Sign (Sub-Registrar)
      </button>
    </div>
  `).join('');
}

function simulateApproveMutation(id) {
  alert(`✅ Digital Signature Applied by Authorized Sub-Registrar Officer for Application: ${id}\n\n3D Cadastral Register updated successfully with immutable timestamp!`);
}

// 8. DigiLocker Integration Tab
function initDigiLocker() {
  const container = document.getElementById('digilocker-docs-grid');
  if (!container) return;

  const docs = ULPIN_DATASET.digiLockerRecords["29010400281901-BA-FL01-U101"] || [];

  container.innerHTML = docs.map(doc => `
    <div class="doc-card">
      <div>
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
          <span style="font-size: 1.5rem;">📜</span>
          <span class="doc-badge-verified">✓ ${doc.status}</span>
        </div>
        <h4 style="font-size: 0.95rem; font-weight: 700; color: #fff; margin-bottom: 0.3rem;">${doc.docType}</h4>
        <div style="font-size: 0.75rem; color: #9ca3af; margin-bottom: 0.75rem;">${doc.issueAuth}</div>
      </div>

      <div>
        <div style="font-size: 0.72rem; color: #6b7280; font-family: monospace;">Doc Ref: ${doc.docNo}</div>
        <div style="font-size: 0.72rem; color: #6b7280;">Issued: ${doc.issueDate}</div>
        <div style="font-size: 0.65rem; color: #38bdf8; font-family: monospace; word-break: break-all; margin-top: 4px;">SHA256: ${doc.hash.substring(0, 24)}...</div>
        <button class="btn-secondary" style="width: 100%; margin-top: 0.75rem;" onclick="alert('Viewing verified document: ${doc.docType}')">
          View Verified Document
        </button>
      </div>
    </div>
  `).join('');
}

// 9. 3D Bhu-Aadhaar Certificate Modal with QRCode.js
function openCertificateModal() {
  if (!currentActiveUnit || !currentActiveParcel) return;

  const modal = document.getElementById('cert-modal');
  modal.classList.add('open');

  document.getElementById('cert-prop-name').textContent = currentActiveParcel.building.name;
  document.getElementById('cert-unit-no').textContent = currentActiveUnit.unitNo;
  document.getElementById('cert-ulpin-3d').textContent = currentActiveUnit.ulpin3d;
  document.getElementById('cert-surface-ulpin').textContent = currentActiveParcel.surfaceUlpin;
  document.getElementById('cert-owner-name').textContent = currentActiveUnit.owner;
  document.getElementById('cert-aadhaar-masked').textContent = currentActiveUnit.aadhaarMasked;
  document.getElementById('cert-carpet-area').textContent = `${currentActiveUnit.carpetAreaSqM} sq.meters`;
  document.getElementById('cert-uds-share').textContent = `${currentActiveUnit.udsSqM} sq.m (${((currentActiveUnit.udsSqM / currentActiveParcel.totalSurfaceAreaSqM) * 100).toFixed(2)}%)`;
  document.getElementById('cert-z-extent').textContent = `+${currentActiveUnit.zMin}m to +${currentActiveUnit.zMax}m Above Ground Level`;
  document.getElementById('cert-issue-date').textContent = new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

  // Generate QR Code
  const qrContainer = document.getElementById('qrcode-canvas');
  qrContainer.innerHTML = '';
  new QRCode(qrContainer, {
    text: `GOVT-INDIA:3D-ULPIN:${currentActiveUnit.ulpin3d}|OWNER:${currentActiveUnit.owner}|SURFACE:${currentActiveParcel.surfaceUlpin}`,
    width: 110,
    height: 110,
    colorDark: "#0f172a",
    colorLight: "#ffffff",
    correctLevel: QRCode.CorrectLevel.H
  });
}

function closeCertificateModal() {
  const modal = document.getElementById('cert-modal');
  modal.classList.remove('open');
}

function printCertificate() {
  window.print();
}

// 10. Global Search Handler
function handleGlobalSearch(query) {
  if (!query) return;
  const q = query.toLowerCase();

  for (const parcel of ULPIN_DATASET.parcels) {
    if (parcel.surfaceUlpin.toLowerCase().includes(q) || parcel.surveyNo.toLowerCase().includes(q) || parcel.building.name.toLowerCase().includes(q)) {
      document.querySelector('[data-tab="3d"]').click();
      document.getElementById('building-selector').value = parcel.id;
      viewer3D.loadBuilding(parcel);
      populateFloorList(parcel);
      return;
    }

    for (const floor of parcel.building.floors) {
      for (const unit of floor.units) {
        if (unit.ulpin3d.toLowerCase().includes(q) || unit.unitNo.toLowerCase().includes(q) || unit.owner.toLowerCase().includes(q)) {
          document.querySelector('[data-tab="3d"]').click();
          document.getElementById('building-selector').value = parcel.id;
          viewer3D.loadBuilding(parcel);
          populateFloorList(parcel);
          viewer3D.selectFloorByIndex(floor.floorIndex);
          updateSidebarInfo(unit, floor, parcel);
          return;
        }
      }
    }
  }

  alert(`No matching 3D ULPIN or property found for query: "${query}"`);
}

// 11. Live Clock
function initLiveClock() {
  const clockEl = document.getElementById('live-clock');
  if (!clockEl) return;
  setInterval(() => {
    const now = new Date();
    clockEl.textContent = now.toLocaleTimeString('en-IN', { hour12: false }) + ' IST';
  }, 1000);
}

// 12. Export Active 3D Parcel as 3D GeoJSON
function exportActiveParcelGeoJSON() {
  if (!currentActiveParcel) {
    alert("No active 3D parcel loaded.");
    return;
  }

  const features = [];

  // Base Cadastral Parcel Polygon Feature
  const polygonCoords = currentActiveParcel.polygon.map(coord => [coord[1], coord[0]]);
  polygonCoords.push(polygonCoords[0]); // close polygon loop

  features.push({
    type: "Feature",
    geometry: {
      type: "Polygon",
      coordinates: [polygonCoords]
    },
    properties: {
      featureType: "CadastralParcelSurface",
      surfaceUlpin: currentActiveParcel.surfaceUlpin,
      surveyNo: currentActiveParcel.surveyNo,
      buildingName: currentActiveParcel.building.name,
      baseElevationMSL: currentActiveParcel.baseElevationMsl,
      sanctionedFAR: currentActiveParcel.sanctionedFAR,
      actualFAR: currentActiveParcel.actualFAR,
      totalUnits: currentActiveParcel.totalUnits
    }
  });

  // Vertical 3D Property Units Features
  currentActiveParcel.building.floors.forEach(floor => {
    floor.units.forEach(unit => {
      features.push({
        type: "Feature",
        geometry: {
          type: "Polygon",
          coordinates: [polygonCoords]
        },
        properties: {
          featureType: "Volumetric3DPropertyUnit",
          ulpin3D: unit.ulpin3d,
          surfaceUlpin: currentActiveParcel.surfaceUlpin,
          unitNo: unit.unitNo,
          floorCode: floor.floorCode,
          floorIndex: floor.floorIndex,
          zMinAGL: unit.zMin,
          zMaxAGL: unit.zMax,
          elevationMSL: currentActiveParcel.baseElevationMsl + unit.zMin,
          carpetAreaSqM: unit.carpetAreaSqM,
          udsSqM: unit.udsSqM,
          ownerName: unit.owner,
          aadhaarMasked: unit.aadhaarMasked,
          status: unit.status,
          mortgage: unit.mortgage
        }
      });
    });
  });

  const geoJsonData = {
    type: "FeatureCollection",
    name: `3D_Bhu_Aadhaar_Cadastre_${currentActiveParcel.surfaceUlpin}`,
    crs: {
      type: "name",
      properties: { name: "urn:ogc:def:crs:OGC:1.3:CRS84" }
    },
    features: features
  };

  const blob = new Blob([JSON.stringify(geoJsonData, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `3D_ULPIN_Parcel_${currentActiveParcel.surfaceUlpin}.geojson`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// 13. SIH Guided Demo Tour Engine
let currentTourStep = 0;
const tourSteps = [
  {
    title: "1. 14-Digit Surface + Volumetric Z-Altitude Cadastre",
    desc: "Extends 2D ULPIN surface parcel coordinates into 3D Volumetric Property Units incorporating height above ground level (AGL) and MSL elevation.",
    action: () => {
      document.querySelector('[data-tab="3d"]').click();
      viewer3D.focusCamera('iso');
      viewer3D.setAutoRotate(true);
    }
  },
  {
    title: "2. Exploded Floor Layer Stratification",
    desc: "Dynamically explodes floors along the Z-axis to visually inspect multi-tiered ownership, elevator cores, and unit divisions.",
    action: () => {
      viewer3D.setExplode(0.5);
      document.getElementById('explode-slider').value = 0.5;
    }
  },
  {
    title: "3. Sub-surface Underground Utility Infrastructure",
    desc: "Visualizes underground metro alignment (Namma Metro Purple Line at Z: -18.5m MSL), water main ducts, and deep piling foundations.",
    action: () => {
      viewer3D.setSubSurface(true);
      document.getElementById('subsurface-toggle-btn').classList.add('active');
    }
  },
  {
    title: "4. Cryptographic Bhu-Aadhaar & Encumbrance Validation",
    desc: "Validates Aadhaar title holder hash, Undivided Share of Land (UDS %), and civil dispute court stay orders.",
    action: () => {
      viewer3D.setXRay(true);
      document.getElementById('xray-toggle-btn').classList.add('active');
    }
  },
  {
    title: "5. Official 3D Deed Certificate & 3D GeoJSON Export",
    desc: "Generates official Govt of India 3D Bhu-Aadhaar deed certificate with dynamic QR code & exports 3D GeoJSON format.",
    action: () => {
      openCertificateModal();
    }
  }
];

function startDemoTour() {
  currentTourStep = 0;
  document.getElementById('sih-tour-banner').style.display = 'flex';
  runTourStep(0);
}

function runTourStep(idx) {
  if (idx < 0 || idx >= tourSteps.length) {
    stopDemoTour();
    return;
  }
  currentTourStep = idx;
  const step = tourSteps[idx];
  document.getElementById('tour-step-badge').textContent = `STEP ${idx + 1} / ${tourSteps.length}`;
  document.getElementById('tour-step-title').textContent = step.title;
  document.getElementById('tour-step-desc').textContent = step.desc;
  step.action();
}

function nextTourStep() {
  runTourStep(currentTourStep + 1);
}

function stopDemoTour() {
  document.getElementById('sih-tour-banner').style.display = 'none';
  if (viewer3D) {
    viewer3D.setAutoRotate(false);
    viewer3D.setExplode(0);
    viewer3D.setSubSurface(false);
    viewer3D.setXRay(false);
    document.getElementById('explode-slider').value = 0;
    document.querySelectorAll('.canvas-btn').forEach(b => b.classList.remove('active'));
  }
}

// 14. 3D Volumetric Property Tax Calculator
function calculatePropertyTax() {
  if (!currentActiveUnit || !currentActiveParcel) {
    alert("Please select a 3D property unit first.");
    return;
  }

  const baseRateSqM = currentActiveParcel.landUse.includes('Commercial') ? 120 : 65;
  const heightMultiplier = 1 + (currentActiveUnit.zMin / 100); // Higher floors have elevation factor
  const annualTax = Math.round(currentActiveUnit.carpetAreaSqM * baseRateSqM * heightMultiplier);
  const stampDuty = Math.round(annualTax * 4.5);

  alert(`🧮 3D Volumetric Property Assessment for ULPIN:\n${currentActiveUnit.ulpin3d}\n\n` +
        `• Title Holder: ${currentActiveUnit.owner}\n` +
        `• Carpet Area: ${currentActiveUnit.carpetAreaSqM} sq.m\n` +
        `• Vertical Elevation Factor (Z: +${currentActiveUnit.zMin}m): x${heightMultiplier.toFixed(2)}\n` +
        `• Annual Property Tax (BBMP/Govt Rate): ₹${annualTax.toLocaleString('en-IN')}\n` +
        `• Estimated Transfer e-Stamp Duty (5%): ₹${stampDuty.toLocaleString('en-IN')}`);
}

// 15. AI Volumetric Compliance & FAR Scanner Engine
function runAIComplianceScan() {
  if (!currentActiveParcel) {
    alert("Please select or load a 3D parcel first.");
    return;
  }

  const p = currentActiveParcel;
  const isViolation = p.actualFAR > p.sanctionedFAR;
  const farDiff = (p.actualFAR - p.sanctionedFAR).toFixed(2);
  const totalHeight = p.building.towerHeightM || 28;
  const totalVolume = Math.round(p.totalSurfaceAreaSqM * totalHeight * 0.7);
  
  // AI Valuation prediction
  const baseRate = p.landUse.includes('Commercial') ? 16500 : 9200;
  const viewPremium = currentActiveUnit ? 1 + (currentActiveUnit.zMin * 0.012) : 1.1;
  const estValuation = Math.round((currentActiveUnit ? currentActiveUnit.carpetAreaSqM : 1200) * baseRate * viewPremium);

  const container = document.getElementById('ai-scanner-content');
  if (!container) return;

  container.innerHTML = `
    <div style="font-family: monospace; font-size: 0.8rem; background: #0b0f19; padding: 10px 14px; border-radius: 8px; color: #60a5fa; margin-bottom: 1.25rem; border: 1px solid rgba(59, 130, 246, 0.3);">
      Target Parcel: <strong>${p.building.name}</strong> (${p.surveyNo}) • 14-Digit ULPIN: <strong>${p.surfaceUlpin}</strong>
    </div>

    <!-- Metrics Grid -->
    <div class="spec-grid" style="margin-bottom: 1.25rem;">
      <div class="spec-card">
        <div class="spec-label">Sanctioned FAR Limit</div>
        <div class="spec-value" style="color: #10b981;">${p.sanctionedFAR}x</div>
      </div>
      <div class="spec-card">
        <div class="spec-label">Scanned Volumetric FAR</div>
        <div class="spec-value" style="color: ${isViolation ? '#ef4444' : '#10b981'};">${p.actualFAR}x</div>
      </div>
      <div class="spec-card">
        <div class="spec-label">Volumetric Spatial Capacity</div>
        <div class="spec-value" style="color: #38bdf8;">${totalVolume.toLocaleString('en-IN')} m³</div>
      </div>
      <div class="spec-card">
        <div class="spec-label">Sub-Surface Metro Buffer</div>
        <div class="spec-value" style="color: #10b981;">✓ Safe (>12m)</div>
      </div>
    </div>

    <!-- AI Diagnostic Report -->
    <div style="background: rgba(15, 23, 42, 0.8); border: 1px solid ${isViolation ? 'rgba(239, 68, 68, 0.5)' : 'rgba(16, 185, 129, 0.5)'}; border-radius: 10px; padding: 1rem; margin-bottom: 1.25rem;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
        <span style="font-weight: 800; font-size: 0.88rem; color: ${isViolation ? '#fca5a5' : '#86efac'};">
          ${isViolation ? '⚠️ VOLUMETRIC FAR OVERBUILD DETECTED (+ ' + farDiff + ' FAR)' : '✅ 100% VOLUMETRIC ENVELOPE COMPLIANT'}
        </span>
        <span class="status-badge ${isViolation ? 'disputed' : 'registered'}">${isViolation ? 'Action Required' : 'Certified Clear'}</span>
      </div>
      <p style="font-size: 0.78rem; color: #cbd5e1; line-height: 1.45;">
        ${isViolation ? 
          `AI LiDAR LoD3 scanner detected unauthorized vertical extension of ~${Math.round(farDiff * 140)} sq.m on top structural tier. Overbuilt volumetric floor exceeds municipality sanctioned FAR by ${(farDiff / p.sanctionedFAR * 100).toFixed(1)}%.` :
          `Building footprint and vertical 3D height profile strictly adhere to approved DILRMP masterplan, setback offsets, and maximum height caps.`}
      </p>
    </div>

    <!-- AI Valuation Matrix -->
    <div style="background: linear-gradient(135deg, rgba(37, 99, 235, 0.12), rgba(6, 182, 212, 0.12)); border: 1px solid rgba(59, 130, 246, 0.3); border-radius: 10px; padding: 1rem; margin-bottom: 1.25rem;">
      <div style="font-size: 0.75rem; font-weight: 800; color: #93c5fd; text-transform: uppercase; margin-bottom: 4px;">🧠 AI 3D Hedonic Valuation Estimate</div>
      <div style="display: flex; justify-content: space-between; align-items: baseline;">
        <div style="font-size: 1.5rem; font-weight: 900; color: #fff;">₹${estValuation.toLocaleString('en-IN')}</div>
        <div style="font-size: 0.75rem; color: #34d399;">View Premium Factor: ${(viewPremium).toFixed(2)}x</div>
      </div>
      <div style="font-size: 0.72rem; color: #9ca3af; margin-top: 4px;">Computed via 3D vertical elevation factor, carpet area UDS weightage, and zone guidance rates.</div>
    </div>

    <!-- Action Buttons -->
    <div style="display: flex; gap: 0.75rem;">
      <button class="btn-primary" style="flex: 1;" onclick="toggleFARHighlight()">
        <span>👁️</span> Highlight 3D Volumetric Box
      </button>
      <button class="btn-secondary" style="flex: 1;" onclick="closeAIScannerModal()">
        Close Scanner
      </button>
    </div>
  `;

  document.getElementById('ai-scanner-modal').classList.add('open');
}

function closeAIScannerModal() {
  const modal = document.getElementById('ai-scanner-modal');
  if (modal) modal.classList.remove('open');
}

let isFARHighlighted = false;
function toggleFARHighlight() {
  isFARHighlighted = !isFARHighlighted;
  if (viewer3D) {
    viewer3D.setFARViolation(isFARHighlighted);
  }
  closeAIScannerModal();
}

